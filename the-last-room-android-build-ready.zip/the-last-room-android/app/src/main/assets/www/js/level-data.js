/* THE LAST ROOM - level configuration (data only, no rendering code). 10 chapters x 5 levels.
   Object kinds: pick | note | puzzle | lock | switch | portal | door | cp
   Common keys: x hy oy v lab need[] nm hide hideIf world crouch give set msg anim sfx
   steps: [flag, objective text, hint text] - objective shows the first step whose flag is not yet set. */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const it = (id, name, type, desc, x) => Object.assign({ id, name, type, desc }, x || {});
  const N = (x, title, text, o) => Object.assign({ k: 'note', x, title, text, v: 'paper', kind2: 'letter' }, o);
  const IN = (x, title, text, o) => Object.assign({ k: 'note', x, title, text, v: 'paper', keep: false, kind2: 'inspect' }, o);
  const P = (x, item, o) => Object.assign({ k: 'pick', x, item, v: 'loose' }, o);
  const Z = (x, pz, cfg, o) => Object.assign({ k: 'puzzle', x, pz, cfg: cfg || {}, v: 'panel' }, o);
  const LK = (x, key, o) => Object.assign({ k: 'lock', x, key, v: 'panel' }, o);
  const SW = (x, set, o) => Object.assign({ k: 'switch', x, set, v: 'lever' }, o);
  const D = (x, o) => Object.assign({ k: 'door', x, v: 'door' }, o);
  const CP = x => ({ k: 'cp', x, v: 'cp' });
  const PT = (x, to, o) => Object.assign({ k: 'portal', x, to, v: 'portal' }, o);
  const SHARD = (n, digit, name) => it('shard' + n, 'Shard of the ' + name, 'shard', 'A cold crystal shard from the ' + name + '. A single number is engraved into it: ' + digit + '.', { g: ['key', 'sun', 'drop', 'gear', 'atom', 'ankh', 'crown', 'eye', 'star'][n - 1], digit });
  const CH = [
    { n: 1, name: 'Abandoned Mansion', theme: 'mansion', tag: 'Dust remembers.', intro: 'You wake on cold floorboards in a house you do not know. A name hums in your head: Verran. Somewhere beneath these rooms, something is waiting.', outro: 'Behind the mural the house ends and something older begins. The shard in your hand is warm. Memory number one.' },
    { n: 2, name: 'Dark City', theme: 'city', tag: 'Neon on wet stone.', intro: 'The cellar door opens onto rain. A whole city sleeps in the dark, its lights drained by an unseen hand. Verran\'s mark is on every wall.', outro: 'Under the hotel the city\'s streets fall away. The second shard pulses like a heartbeat.' },
    { n: 3, name: 'Underground Sewer', theme: 'sewer', tag: 'The city\'s hidden veins.', intro: 'Green light, black water, the drip of ancient pipes. Verran hid his work where nobody would ever look.', outro: 'A forgotten tunnel exhales warm, oily air. Ahead, machines are humming.' },
    { n: 4, name: 'Old Factory', theme: 'factory', tag: 'Gears of a buried plan.', intro: 'A factory that never stopped dreaming. Its machines were not built to make things - they were built to make a door.', outro: 'The foreman\'s office hides a lift going down. Down to clean white light.' },
    { n: 5, name: 'Secret Laboratory', theme: 'lab', tag: 'Where the experiment began.', intro: 'Blue light. Glass. A child\'s drawing taped to a monitor. Project THRESHOLD started here - and you were in the room.', outro: 'You remember a girl\'s laughter. A name: Mira. The core opens onto stone and moss.' },
    { n: 6, name: 'Ancient Temple', theme: 'temple', tag: 'Older than the house.', intro: 'The machine did not create these places. It found them. Verran was only the first to knock on this door.', outro: 'The chamber beneath the temple opens upward - to sky with no ground beneath it.' },
    { n: 7, name: 'Sky Fortress', theme: 'sky', tag: 'Nothing to fall onto.', intro: 'Wind, cloud and broken bridges. A fortress hangs in the sky, and the pylons that held it up have gone dark.', outro: 'The throne room has no king. Only a mirror, and it shows a different world.' },
    { n: 8, name: 'Dream World', theme: 'dream', tag: 'Nothing here is certain.', intro: 'Stairs that climb into themselves. Doors that open on the same room. Your own reflection is learning to move without you.', outro: 'You wake - or something like waking. Below you, the stars are very close.' },
    { n: 9, name: 'Space Station', theme: 'space', tag: 'Last light before the dark.', intro: 'Silent corridors, a blue planet through the glass. The station\'s log ends in a single word: "Threshold."', outro: 'Nine shards, nine memories. One door remains, and it has your name on it.' },
    { n: 10, name: 'The Final Room', theme: 'final', tag: 'Escape. Solve. Survive.', intro: 'Dark stone. Red light. The great ring turns, waiting for the nine shards you carry. This is the room Verran built for you.', outro: '' }
  ];
  const L = [];
  const lv = (id, name, w, theme, o) => { const l = Object.assign({ id, ch: +id.split('-')[0], name, w, theme, objects: [], steps: [], plat: [], recipes: [], intro: [] }, o); l.objects.push(CP(Math.round(w * .5)), D(w - 90, { lab: 'Exit', need: o.req || [], key: o.exitKey, nm: o.exitNm })); L.push(l); return l; };
  /* ============ CHAPTER 1 : MANSION ============ */
  lv('1-1', 'The Awakening Hall', 1400, 'mansion', {
    req: ['open'], dark: .52, intro: ['Kai: Where... am I?', 'Kai: My head hurts. I can\'t remember anything.'],
    steps: [['torch', 'Find a way to light the dark', 'Search the dresser, then crouch (S / the crouch button) to look under the sofa. Open the inventory and combine the two parts.'], ['clock', 'Examine the stopped clock', 'The tall grandfather clock near the middle of the hall.'], ['open', 'Unlock the hall door', 'Tap the tiles on the door lock until every light is on.']],
    recipes: [{ a: 'flash_body', b: 'battery', out: it('flashlight', 'Flashlight', 'tool', 'A reliable beam of light. Lights up dark places.', { keepGlobal: true }), set: 'torch', msg: 'The beam cuts through the dark.' }],
    objects: [N(170, 'Cold Note', 'Kai - if you are reading this, you have woken. The house will not let you leave easily. Look closely at everything. Trust the small details. - E.V.'),
      P(340, it('flash_body', 'Flashlight (empty)', 'tool', 'A heavy flashlight. It has no batteries.'), { v: 'drawer', lab: 'Open dresser', sfx: 'drawer' }),
      P(560, it('battery', 'Battery', 'battery', 'Still holds a charge.'), { v: 'sofa', crouch: true, lab: 'Search under sofa', msg: 'You reach under the sofa and find a battery.' }),
      IN(770, 'Grandfather Clock', 'The clock stopped at 3:17. A scratch on the glass reads: "Time stopped when the house woke up."', { v: 'clock', lab: 'Examine clock', set: 'clock' }),
      IN(980, 'Portrait', 'A pale man in a dark coat. His eyes seem to follow you. The plaque: ELIAS VERRAN, ARCHITECT.', { v: 'painting', lab: 'Examine portrait' }),
      Z(1210, 'lights', { n: 3 }, { v: 'keypad', lab: 'Use keypad', title: 'Door Keypad', need: ['clock'], nm: 'A keypad. It wants a time... maybe the clock can help.', set: 'open', msg: 'The lock releases with a heavy click.', sfx: 'unlock' })]
  });
  lv('1-2', 'Gallery of Faces', 1700, 'mansion', {
    req: [], exitKey: 'library_key', exitNm: 'The library door is locked. A key must be hidden in this gallery.', dark: .5, intro: ['Kai: So many portraits. Every one has a number hidden in it.'],
    steps: [['p1', 'Study the three paintings', 'Look at Portrait I, The Hunt II and The Ship III. Each hides a number.'], ['safe', 'Open the curator\'s safe', 'Swap the coloured tiles into the order shown on the safe.'], ['open', 'Open the library door', 'Use the key from the safe on the library door.']],
    objects: [N(150, 'Family Photograph', 'A photo of a man, a woman and two children in front of this house. One child has been scratched out. On the back: "Before Threshold."', { kind2: 'photo' }),
      IN(330, 'Portrait I', 'A lady in green. She wears a necklace of exactly four pearls. The frame is marked with a gold numeral: I.', { v: 'painting', lab: 'Examine Portrait I', set: 'p1' }),
      IN(640, 'The Hunt II', 'Seven hounds chase a single stag across a dark moor. The frame is marked: II.', { v: 'painting', lab: 'Examine The Hunt' }),
      IN(950, 'The Ship III', 'A ship with two torn masts, sailing into a storm. The frame is marked: III.', { v: 'painting', lab: 'Examine The Ship' }),
      N(1110, 'Curator\'s Letter', 'The safe code is the secret of the frames: read them in the order of their gold numerals - I, II, III.'),
      Z(1280, 'swap', { n: 5 }, { v: 'safe', lab: 'Open safe', title: 'Curator\'s Safe', give: it('library_key', 'Library Key', 'key', 'A tarnished key tagged "LIBRARY".'), set: 'safe', msg: 'Inside the safe lies an old key.', sfx: 'unlock' })]
  });
  lv('1-3', 'The Library', 1900, 'mansion', {
    req: ['open'], zones: [[0, 1480], [1520, 1900]], dark: .55, intro: ['Kai: Something is wrong with these shelves...'],
    steps: [['ped', 'Find the hidden switch', 'Examine the odd painting at the far end of the library.'], ['shelf', 'Solve the bookshelf puzzle', 'Use the bookshelf next to the study lamp.'], ['open', 'Use the secret passage', 'Enter the opened bookshelf passage and pull the lever in the hidden room.']],
    objects: [N(160, 'Marginal Note', 'The red book never sits where it belongs. If the spines tell a story, one is out of place. - E.V.'),
      P(420, it('torn_page', 'Torn Page', 'note', 'A torn journal page: "The house has more rooms than it shows."'), { v: 'paper', lab: 'Pick up page' }),
      IN(760, 'Odd Painting', 'The painting hangs crookedly. Behind it, your fingers find a hidden switch. Click.', { v: 'painting', lab: 'Inspect painting', set: 'ped' }),
      Z(1000, 'pattern', { skin: 'books' }, { v: 'bookshelf', lab: 'Study the bookshelf', title: 'Bookshelf Pattern', need: ['ped'], nm: 'The shelf will not budge.', set: 'shelf', msg: 'The shelf swings aside, revealing a passage.', sfx: 'door' }),
      PT(1010, [1580, 0], { lab: 'Enter secret passage', hide: 'shelf', oy: 0 }),
      PT(1580, [1010, 0], { lab: 'Back to the library', hide: 'shelf' }),
      SW(1720, 'open', { lab: 'Pull hidden lever', msg: 'Far away, a heavy door unlocks.', sfx: 'machine' }),
      N(1800, 'Verran\'s Study Notes', 'Day 41. The rooms keep multiplying. I\'ve stopped counting. - E.V.', { kind2: 'doc' })]
  });
  lv('1-4', 'Upstairs Corridor', 1800, 'mansion', {
    req: [], exitKey: 'attic_key', exitNm: 'The attic door is locked tight.', dark: .55, intro: ['Kai: The attic key is in two pieces. I need to find both halves.'],
    plat: [{ x: 960, w: 90, hy: 40 }, { x: 1050, w: 90, hy: 80 }, { x: 1150, w: 120, hy: 120 }],
    steps: [['half1', 'Search the trunk for the first key half', 'The old trunk in the middle of the corridor hides clutter - find all four objects.'], ['half2', 'Climb the shelves for the second half', 'Use the jump button / Space to climb the steps on the right.'], ['open', 'Combine the halves and open the attic', 'Combine both key halves in the inventory, then use the attic door.']],
    recipes: [{ a: 'key_half1', b: 'key_half2', out: it('attic_key', 'Attic Key', 'key', 'The two halves fit together perfectly.'), msg: 'The two halves lock together.' }],
    objects: [N(160, 'Servants\' Notice', 'The attic is sealed by order of Mr. Verran. Do not ask why.'),
      Z(540, 'hidden', { items: ['key', 'eye', 'leaf', 'moon'], n: 4 }, { v: 'chest', lab: 'Search the trunk', title: 'Old Trunk', give: it('key_half1', 'Key Half (blade)', 'key', 'The blade half of a key.', { half: true }), set: 'half1', msg: 'Under the clutter: half of a key!' }),
      IN(760, 'Cracked Mirror', 'Your reflection is a moment late.', { v: 'mirror', lab: 'Look in mirror' }),
      P(1150, it('key_half2', 'Key Half (bow)', 'key', 'The ring-shaped half of a key.', { half: true }), { hy: 120, lab: 'Take key half', set: 'half2' })]
  });
  lv('1-5', 'The Hidden Basement', 1700, 'mansion', {
    req: ['shard'], zones: [[0, 1200], [1260, 1700]], dark: .62, intro: ['Kai: The mural is hiding something. The tiles look like they can slide.'],
    steps: [['mural', 'Restore the mural', 'The big mural on the wall is a sliding picture puzzle.'], ['down', 'Descend into the basement', 'A hidden door has opened behind the mural.'], ['shard', 'Take the shard from the pedestal', 'The glowing pedestal in the hidden basement.']],
    objects: [N(170, 'Verran\'s Journal, p.1', 'I have begun. THRESHOLD will open a door between places that were never meant to meet. My daughter believes it will bring back her brother\'s memory. God help us both.', { kind2: 'doc' }),
      IN(420, 'Dusty Locker', 'Empty, apart from a child\'s drawing: a house, a ring, and two smiling figures.', { v: 'locker', lab: 'Search locker' }),
      Z(760, 'slide', { n: 3, g: 'eye', c1: '#7a3aa0' }, { v: 'painting', oy: 40, lab: 'Examine mural', title: 'The Mural', set: 'mural', msg: 'The mural clicks into place. A door opens behind it.', sfx: 'door' }),
      PT(900, [1300, 0], { lab: 'Descend', hide: 'mural', v: 'hatch' }),
      PT(1300, [900, 0], { lab: 'Climb up', hide: 'mural', v: 'hatch' }),
      N(1420, 'Recording: Elias Verran', '"Test one. The subject is stable. His name is Kai. He remembers nothing. That is for the best."', { kind2: 'audio', v: 'radio' }),
      P(1540, SHARD(1, 3, 'Mansion'), { v: 'pedestal', lab: 'Take the shard', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 2 : DARK CITY ============ */
  lv('2-1', 'Rain-Slick Street', 1800, 'city', {
    req: ['power'], powerFlag: 'power', dark: .6, intro: ['Kai: The whole city is dark. I need to get the power back on.'],
    steps: [['fuse', 'Find a fuse', 'Search the dumpster by the shop front.'], ['fuse_in', 'Install the fuse in the fuse box', 'The fuse box is on the wall to the right.'], ['power', 'Restart the generator', 'Solve the generator\'s circuit: light every node.']],
    objects: [N(160, 'Wet Flyer', 'CITY BLACKOUT - 3 YEARS AND COUNTING. DO NOT APPROACH THE HOTEL.', { kind2: 'doc' }),
      Z(480, 'hidden', { items: ['bolt', 'key', 'drop'], n: 3, pal: ['#1a1a24', '#2a2a38', '#3a3a4c', '#22202c'] }, { v: 'bin', lab: 'Search dumpster', title: 'Dumpster', give: it('fuse', 'Fuse', 'comp', 'A blown-looking glass fuse. Might still work.'), set: 'fuse', msg: 'You find a working fuse.' }),
      LK(900, 'fuse', { v: 'fusebox', oy: 20, lab: 'Fuse box', need: ['fuse'], nm: 'The fuse box is missing its fuse.', set: 'fuse_in', msg: 'The fuse slots in. The generator coughs.' }),
      Z(1300, 'circuit', { d: 1 }, { v: 'generator', lab: 'Start generator', title: 'Generator', need: ['fuse_in'], nm: 'The generator has no power feed.', set: 'power', msg: 'Neon flickers back to life across the street!', sfx: 'power' })]
  });
  lv('2-2', 'The Alley', 1700, 'city', {
    req: ['open'], powerFlag: 'power', dark: .62, intro: ['Kai: Spray-painted numbers. Someone left a code for me.'],
    steps: [['g1', 'Find the graffiti numbers', 'Red, green and blue graffiti on the alley walls.'], ['open', 'Open the shutter', 'Connect the wires on the shutter panel.']],
    objects: [IN(330, 'Red Graffiti', 'Dripping red paint: a big number 6.', { v: 'paper', lab: 'Examine red graffiti', set: 'g1' }), N(520, 'Torn Flyer', 'SHUTTER LOCK: three colours open the way - RED, then GREEN, then BLUE.'),
      IN(740, 'Green Graffiti', 'Glowing green paint: the number 1.', { v: 'paper', lab: 'Examine green graffiti' }), P(900, it('coin', 'Old Coin', 'special', 'A silver coin stamped with a ring symbol.', { g: 'spiral' }), { crouch: true, v: 'loose', lab: 'Look under stairs' }),
      IN(1080, 'Blue Graffiti', 'Cold blue paint: the number 4.', { v: 'paper', lab: 'Examine blue graffiti' }),
      Z(1480, 'circuit', { d: 1 }, { v: 'keypad', lab: 'Use shutter keypad', title: 'Shutter Keypad', need: ['g1'], nm: 'A keypad. Maybe the graffiti is the code.', set: 'open', msg: 'The shutter rattles upward.', sfx: 'door' })]
  });
  lv('2-3', 'Hotel Lobby', 1700, 'city', {
    req: ['elev'], dark: .55, intro: ['Kai: The elevator panel needs a card. Maybe reception has one.'],
    steps: [['card', 'Find a room access card', 'Search behind the reception desk - crouch to look inside.'], ['elev_pow', 'Power the elevator panel', 'Use the access card on the elevator panel.'], ['elev', 'Solve the floor sequence', 'Connect the pipes to bring the lift to life.']],
    objects: [N(170, 'Guest Ledger', 'Penthouse guest: E. Verran. Never checked out. Floors hum their own tune.', { kind2: 'doc' }),
      P(520, it('access_card', 'Access Card', 'card', 'A plastic card: HOTEL STAFF.'), { v: 'desk', crouch: true, lab: 'Search behind desk', set: 'card' }),
      N(800, 'Torn Photograph', 'Two children on a hotel balcony. The girl is pointing at the camera, laughing.', { kind2: 'photo', v: 'photo' }),
      LK(1100, 'access_card', { use: false, v: 'panel', lab: 'Elevator card reader', need: ['card'], nm: 'A card reader. It needs a card.', set: 'elev_pow', msg: 'The reader chirps.' }),
      Z(1330, 'pipes', { d: 1 }, { v: 'elevator', lab: 'Elevator control', title: 'Elevator Panel', need: ['elev_pow'], nm: 'The elevator is dead.', set: 'elev', msg: 'The elevator hums to life.', sfx: 'power' })]
  });
  lv('2-4', 'Hotel Rooms', 1900, 'city', {
    req: [], exitKey: 'roof_key', exitNm: 'The roof access door needs a key.', dark: .6, plat: [{ x: 1000, w: 120, hy: 45 }, { x: 1130, w: 120, hy: 90 }],
    steps: [['tool', 'Find a screwdriver', 'Crouch to look in the air vent on the left.'], ['panel', 'Open the wall panel', 'Use the screwdriver on the wall panel.'], ['open', 'Get the roof key and use the roof door', 'Complete the pattern on the music box.']],
    objects: [N(150, 'Do Not Disturb', 'Room 3: nobody has opened this door since the lights went out. The chimes still play at midnight.'),
      P(380, it('screwdriver', 'Screwdriver', 'tool', 'A flat-head screwdriver.'), { v: 'vent', crouch: true, lab: 'Look in air vent', set: 'tool' }),
      LK(700, 'screwdriver', { v: 'panel', oy: 40, lab: 'Wall panel', need: ['tool'], nm: 'A sealed wall panel with screws.', set: 'panel', msg: 'The screws come loose. A music box is inside.' }),
      Z(880, 'pattern', { d: 1 }, { v: 'radio', lab: 'Play music box', title: 'Music Box', need: ['panel'], nm: 'There is a panel in the way.', give: it('roof_key', 'Roof Key', 'key', 'A heavy key with a rusted tag: ROOF.'), msg: 'The music box opens. A key is inside.' }),
      N(1130, 'Penthouse Note', 'The roof leads to the underground. Do not look down.', { hy: 90, kind2: 'letter' })]
  });
  lv('2-5', 'Underground Entrance', 1700, 'city', {
    req: ['shard'], dark: .58, intro: ['Kai: A manhole winch. The gears are jammed.'],
    steps: [['cover', 'Free the winch gears', 'Turn the winch gears until every marker points up.'], ['shard', 'Take the shard', 'The pedestal beyond the opened manhole.']],
    objects: [N(160, 'Maintenance Order', 'MANHOLE 7 - DO NOT OPEN. THE CITY IS NOT EMPTY.', { kind2: 'doc' }), IN(500, 'Chalk Marks', 'Chalk tally marks and a spiral drawn over and over.', { v: 'paper', lab: 'Examine marks' }),
      Z(900, 'gears', { n: 4, pos: 4 }, { v: 'machine', lab: 'Operate winch', title: 'Manhole Winch', set: 'cover', msg: 'The manhole cover grinds open.', sfx: 'machine' }),
      P(1320, SHARD(2, 8, 'Dark City'), { v: 'pedestal', lab: 'Take the shard', need: ['cover'], nm: 'The pedestal is sealed under the cover.', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 3 : SEWER ============ */
  lv('3-1', 'Drain Outfall', 1800, 'sewer', {
    req: ['flow'], waterFlag: 'flow', dark: .64, intro: ['Kai: The water is rising. I need to open a channel.'],
    steps: [['wrench', 'Find a wrench', 'Crouch to look under the grate.'], ['valve', 'Open the rusty valve', 'Use the wrench on the valve.'], ['flow', 'Connect the pipes', 'Rotate the pipes so water can flow from left to right.']],
    objects: [N(160, 'Work Order', 'Outfall 3 floods without warning. Open the valve BEFORE touching the pipe junction.', { kind2: 'doc' }),
      P(430, it('wrench', 'Pipe Wrench', 'tool', 'Heavy, rusty and still strong.'), { v: 'vent', crouch: true, lab: 'Look under grate', set: 'wrench' }),
      LK(800, 'wrench', { v: 'valve', oy: 30, lab: 'Rusty valve', need: ['wrench'], nm: 'The valve is rusted solid.', set: 'valve', msg: 'The valve turns with a groan.' }),
      Z(1250, 'pipes', { d: 1 }, { v: 'panel', lab: 'Pipe junction', title: 'Pipe Junction', need: ['valve'], nm: 'The junction has no pressure.', set: 'flow', msg: 'Water roars through the pipes and the channel drains.', sfx: 'water' })]
  });
  lv('3-2', 'Valve Hall', 1900, 'sewer', {
    req: ['drained'], waterFlag: 'drained', zones: [[0, 1560], [1600, 1900]], dark: .64,
    steps: [['v1', 'Turn the first set of valves', 'Align every valve handle to point up.'], ['drained', 'Drain the hall', 'Turn the second set of valves.']],
    objects: [N(170, 'Pump Log', 'To lower the water, turn valve bank one, then bank two. Bank two needs bank one open first.', { kind2: 'doc' }),
      Z(720, 'gears', { n: 4, pos: 4, skin: 'valve' }, { v: 'valve', oy: 30, lab: 'Valve bank one', title: 'Valve Bank One', set: 'v1', msg: 'Water starts to fall.' }),
      Z(1180, 'gears', { n: 5, pos: 4, skin: 'valve' }, { v: 'valve', oy: 30, lab: 'Valve bank two', title: 'Valve Bank Two', need: ['v1'], nm: 'Locked until bank one is open.', set: 'drained', msg: 'The hall drains. A hidden tunnel is revealed!', sfx: 'water' }),
      PT(1450, [1660, 0], { lab: 'Enter hidden tunnel', hide: 'drained', v: 'hatch' }), PT(1660, [1450, 0], { lab: 'Back to the hall', hide: 'drained', v: 'hatch' }),
      N(1760, 'Scratched Wall', 'Verran came this way. So did a child. Her handprint is in the soot.', { kind2: 'letter' })]
  });
  lv('3-3', 'Pressure Chamber', 1700, 'sewer', {
    req: ['plates'], dark: .66,
    steps: [['gauge', 'Find the pressure gauge', 'Pick up the gauge dial from the panel on the left.'], ['gauge_ok', 'Mount the gauge', 'Install it in the gauge socket.'], ['plates', 'Solve the pressure plates', 'Step on the plates in the right order.']],
    objects: [N(150, 'Engineer\'s Warning', 'The plates answer to a riddle. Step wrongly and they all spring back.', { kind2: 'doc' }),
      P(320, it('gauge', 'Gauge Dial', 'comp', 'A brass pressure gauge dial.'), { v: 'panel', oy: 30, lab: 'Take gauge dial', set: 'gauge' }),
      LK(650, 'gauge', { v: 'panel', oy: 30, lab: 'Gauge socket', need: ['gauge'], nm: 'An empty socket for a gauge.', set: 'gauge_ok', msg: 'The needle swings to green.' }),
      Z(1050, 'plates', { order: ['drop', 'wave', 'flame', 'bolt'] }, { v: 'plate', lab: 'Pressure plates', title: 'Pressure Plates', need: ['gauge_ok'], nm: 'The plates are dead.', set: 'plates', msg: 'The pressure door unlocks.', sfx: 'machine' })]
  });
  lv('3-4', 'Rusty Tunnel', 1900, 'sewer', {
    req: ['open', 'pump'], plat: [{ x: 880, w: 110, hy: 45 }, { x: 990, w: 110, hy: 90 }], dark: .66,
    steps: [['log', 'Read the maintenance log', 'The log is on the high catwalk. Jump up the steps.'], ['open', 'Open the rusty door', 'Connect the pipes to open the rusty door.'], ['pump', 'Fix the pump', 'Find the pump handles and install them.']],
    objects: [N(990, 'Maintenance Log', 'Pump codes: ALPHA 2, BETA 0, GAMMA 5, DELTA 7. Door sequence: Gamma, Alpha, Delta, Beta.', { hy: 90, kind2: 'doc', set: 'log' }),
      Z(1250, 'pipes', { d: 1 }, { v: 'keypad', lab: 'Rusty door keypad', title: 'Rusty Door', need: ['log'], nm: 'A four-digit keypad. The log might help.', set: 'open', msg: 'The rusty door shrieks open.', sfx: 'door' }),
      Z(520, 'hidden', { items: ['gear', 'drop', 'bolt'], n: 3, pal: ['#16241c', '#26382c', '#36483c', '#101c16'] }, { v: 'crate', lab: 'Search wreckage', title: 'Wreckage', give: it('pump_handle', 'Pump Handle', 'tool', 'A heavy cast-iron pump handle.'), msg: 'You find the pump handle.' }),
      LK(1600, 'pump_handle', { v: 'valve', oy: 30, lab: 'Pump', set: 'pump', msg: 'The pump shudders into motion.', sfx: 'machine' })]
  });
  lv('3-5', 'The Hidden Tunnel', 1800, 'sewer', {
    req: ['shard'], zones: [[0, 1350], [1400, 1800]], dark: .68,
    steps: [['sluice', 'Restore the sluice relays', 'Light all the relay nodes.'], ['shard', 'Take the shard', 'It lies in the hidden chamber beyond the sluice.']],
    objects: [N(160, 'Soot-Stained Page', 'Miss Verran\'s notebook: "Father says the door will take us home. Kai doesn\'t want to go."', { kind2: 'letter' }),
      Z(760, 'circuit', { d: 2, w: 4, h: 3 }, { v: 'panel', lab: 'Sluice relays', title: 'Sluice Relays', set: 'sluice', msg: 'The sluice gate lifts. A hidden passage appears.', sfx: 'power' }),
      PT(1200, [1450, 0], { lab: 'Enter hidden chamber', hide: 'sluice', v: 'hatch' }), PT(1450, [1200, 0], { lab: 'Back', hide: 'sluice', v: 'hatch' }),
      P(1640, SHARD(3, 1, 'Sewer'), { v: 'pedestal', lab: 'Take the shard', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 4 : FACTORY ============ */
  lv('4-1', 'Loading Dock', 1900, 'factory', {
    req: ['count'], dark: .5, steps: [['fuse', 'Find a fuse', 'The crate on the left.'], ['power', 'Restore breaker power', 'Use the fuse on the breaker.'], ['conv', 'Start the conveyor', 'Pull the conveyor lever.'], ['count', 'Count the crates', 'Swap the crates into the right order.']],
    objects: [N(150, 'Shift Memo', 'Conveyor A feeds the crate counter. No power, no count. - Foreman H.', { kind2: 'doc' }),
      P(320, it('fuse2', 'Heavy Fuse', 'comp', 'An industrial fuse.'), { v: 'crate', lab: 'Open crate', set: 'fuse' }),
      LK(700, 'fuse2', { v: 'fusebox', oy: 20, lab: 'Breaker box', need: ['fuse'], nm: 'The breaker is missing a fuse.', set: 'power', msg: 'The breaker clunks. Lights flicker on.', sfx: 'power' }),
      SW(1050, 'conv', { lab: 'Conveyor lever', need: ['power'], nm: 'No power.', msg: 'The conveyor belt rumbles to life.', sfx: 'machine' }),
      Z(1400, 'swap', { n: 4 }, { v: 'terminal', lab: 'Crate counter', title: 'Crate Counter', need: ['conv'], nm: 'The counter is idle - the belt is stopped.', set: 'count', msg: 'The counter accepts the tally.' })]
  });
  lv('4-2', 'Machine Hall', 2000, 'factory', {
    req: ['machine'], dark: .5, steps: [['grid', 'Distribute the power', 'Light every node of the power grid.'], ['calib', 'Calibrate the gauge array', 'Find the odd piece out in the gauge matrix.'], ['machine', 'Start the main machine', 'Pull the main lever.']],
    objects: [N(160, 'Manual p.12', 'Main machine start-up: (1) power grid, (2) gauge calibration, (3) lever.', { kind2: 'doc' }),
      Z(700, 'circuit', { d: 2, w: 3, h: 4 }, { v: 'panel', lab: 'Power grid', title: 'Power Grid', set: 'grid', msg: 'Power surges through the factory.', sfx: 'power' }),
      Z(1100, 'lights', { n: 4 }, { v: 'console', lab: 'Gauge array', title: 'Gauge Calibration', need: ['grid'], nm: 'The gauges have no power.', set: 'calib', msg: 'The gauges settle at zero.' }),
      SW(1500, 'machine', { v: 'lever', lab: 'Main lever', need: ['calib'], nm: 'The lever will not move yet.', msg: 'The great machine thunders to life.', sfx: 'machine' }),
      IN(1700, 'Giant Machine', 'A colossal engine. It carries a nameplate: THRESHOLD ASSEMBLY.', { v: 'machine', lab: 'Examine machine' })]
  });
  lv('4-3', 'Gear Chamber', 1800, 'factory', {
    req: ['gears'], dark: .5, plat: [{ x: 400, w: 120, hy: 45 }, { x: 510, w: 110, hy: 80 }],
    steps: [['cog', 'Find the missing cog', 'Climb the platforms on the left.'], ['shaft', 'Install the cog on the shaft', 'Use the cog on the drive shaft.'], ['gears', 'Align the gears', 'Align every gear marker to the top.']],
    objects: [P(510, it('cog', 'Cog', 'comp', 'A large steel cog.'), { hy: 80, lab: 'Take cog', set: 'cog' }),
      LK(800, 'cog', { v: 'gear', oy: 24, lab: 'Drive shaft', need: ['cog'], nm: 'The drive shaft is missing a cog.', set: 'shaft', msg: 'The cog fits. The shaft begins to turn.' }),
      N(1000, 'Engineer\'s Diagram', 'Each gear turns its neighbours the other way. Fix them one by one.', { kind2: 'doc' }),
      Z(1300, 'gears', { n: 5, pos: 4, d: 2 }, { v: 'machine', lab: 'Gear console', title: 'Gear Alignment', need: ['shaft'], nm: 'The console has no drive.', set: 'gears', msg: 'The great gears mesh perfectly.', sfx: 'machine' })]
  });
  lv('4-4', 'Catwalks', 2100, 'factory', {
    req: ['open'], dark: .5, plat: [{ x: 500, w: 100, hy: 45 }, { x: 800, w: 90, hy: 70, mv: { ax: 50, ay: 0, sp: 1.1 } }, { x: 1100, w: 110, hy: 80 }, { x: 1400, w: 100, hy: 45 }, { x: 1520, w: 110, hy: 90 }],
    steps: [['have:bolt:3', 'Collect three door bolts', 'Climb the catwalks to reach the bolts.'], ['open', 'Fit the bolts in the mechanical door', 'Use the bolts on the mechanical door.']],
    objects: [N(160, 'Foreman\'s Note', 'The mechanical door needs 3 bolts. They\'re all up on the catwalks. - H.', { kind2: 'letter' }),
      P(500, it('bolt', 'Door Bolt', 'comp', 'A thick steel bolt.', { stack: true }), { hy: 45, id: 'b1' }), P(800, it('bolt', 'Door Bolt', 'comp', 'A thick steel bolt.', { stack: true }), { hy: 70, id: 'b2', oy: 0 }), P(1520, it('bolt', 'Door Bolt', 'comp', 'A thick steel bolt.', { stack: true }), { hy: 90, id: 'b3' }),
      LK(1850, 'bolt', { n: 3, v: 'panel', oy: 30, lab: 'Mechanical door', set: 'open', msg: 'The bolts lock in. The door groans open.', sfx: 'door' })]
  });
  lv('4-5', 'Foreman\'s Office', 1700, 'factory', {
    req: ['shard'], dark: .55,
    steps: [['safe', 'Open the foreman\'s safe', 'Swap the tiles into the right order.'], ['door', 'Open the mechanical lock', 'Solve the sliding-block mechanism.'], ['shard', 'Take the shard', 'The pedestal in the back office.']],
    objects: [N(170, 'Time Card', 'H. Brandt - clock-in 06:45. Never clocked out.', { kind2: 'doc' }),
      Z(560, 'swap', { n: 6 }, { v: 'safe', lab: 'Open safe', title: 'Foreman\'s Safe', give: it('blueprint', 'Blueprint', 'doc', 'A blueprint of the lift shaft going down.'), set: 'safe', msg: 'You take the blueprint.' }),
      Z(1000, 'slide', { n: 3, d: 2, g: 'gear', c1: '#a05a1a' }, { v: 'panel', oy: 30, lab: 'Mechanical lock', title: 'Mechanical Lock', need: ['safe'], nm: 'The lock needs the blueprint.', set: 'door', msg: 'The lock mechanism slides open.', sfx: 'door' }),
      P(1450, SHARD(4, 6, 'Factory'), { v: 'pedestal', lab: 'Take the shard', need: ['door'], nm: 'It lies behind the locked inner door.', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 5 : LAB ============ */
  lv('5-1', 'Decontamination', 1700, 'lab', {
    req: ['decon'], dark: .42, steps: [['poster', 'Read the safety poster', 'The hazard poster on the wall.'], ['decon', 'Match the scientific symbols', 'Match each symbol with its name.']],
    objects: [N(170, 'Welcome Memo', 'Project THRESHOLD, Level 1. Subjects: 1. Visitors must pass decontamination.', { kind2: 'doc' }), IN(520, 'Hazard Poster', 'A poster showing hazard symbols: Atom, Flask, Lightning, Helix, Magnet.', { v: 'paper', lab: 'Read poster', set: 'poster', oy: 30 }),
      Z(1000, 'symbols', { glyphs: ['atom', 'flask', 'bolt', 'dna', 'magnet'], col: '#9fe0ff' }, { v: 'panel', lab: 'Decon scanner', title: 'Decon Scanner', set: 'decon', msg: 'Decontamination complete.', sfx: 'power' })]
  });
  lv('5-2', 'Terminal Room', 1800, 'lab', {
    req: ['term'], exitKey: 'access_card2', exitNm: 'The security door wants a keycard.', dark: .42,
    steps: [['locker', 'Open the locker', 'Find the hidden items around the locker.'], ['term', 'Wake the terminal', 'Complete the pattern on the terminal.']],
    objects: [N(170, 'Memo', 'Locker 4 code = my daughter\'s birthday, month then day. She was born on December 9th. - E.V.', { kind2: 'doc' }),
      Z(560, 'hidden', { items: ['key', 'eye', 'leaf', 'moon'], n: 4 }, { v: 'locker', lab: 'Open locker', title: 'Locker 4', give: it('access_card2', 'Security Keycard', 'card', 'LEVEL 3 CLEARANCE.'), set: 'locker', msg: 'The locker opens. A keycard!' }),
      N(850, 'Photograph', 'A girl with a toothy grin holding a drawing. Written on the back: "Mira - age 9".', { kind2: 'photo', v: 'photo' }),
      Z(1200, 'circuit', { d: 2 }, { v: 'terminal', lab: 'Use terminal', title: 'Terminal Login', set: 'term', msg: 'Welcome back, Dr. Verran. The security system disarms.', sfx: 'power' })]
  });
  lv('5-3', 'Laser Vault', 1800, 'lab', {
    req: ['laser'], dark: .4, steps: [['battery', 'Find a power cell', 'Pick up the battery on the left bench.'], ['emit', 'Power the laser emitter', 'Use the battery on the emitter.'], ['laser', 'Redirect the laser', 'Flip mirrors to guide the beam into the vault sensor.']],
    objects: [N(160, 'Vault Warning', 'The vault opens when the laser hits the sensor. Mirrors are placed by hand.', { kind2: 'doc' }), P(330, it('power_cell', 'Power Cell', 'battery', 'A fully charged power cell.'), { v: 'desk', lab: 'Take power cell', set: 'battery' }),
      LK(700, 'power_cell', { v: 'panel', oy: 30, lab: 'Laser emitter', need: ['battery'], nm: 'The emitter has no power cell.', set: 'emit', msg: 'The emitter hums.' }),
      Z(1150, 'mirror', { d: 1, skin: 'laser' }, { v: 'console', lab: 'Mirror control', title: 'Laser Mirrors', need: ['emit'], nm: 'The emitter is dead.', set: 'laser', msg: 'The vault sensor lights up.', sfx: 'power' })]
  });
  lv('5-4', 'Specimen Hall', 1900, 'lab', {
    req: ['genome'], dark: .42, steps: [['cells', 'Unlock the containment cells', 'Find the hidden items in the lab.'], ['genome', 'Complete the genome matrix', 'Find the missing piece of the matrix.']],
    objects: [N(160, 'Specimen Log', 'Subject K: stable, but forgets. Subject M: ...', { kind2: 'doc' }), Z(700, 'hidden', { items: ['atom', 'flask', 'dna', 'bolt'], n: 4 }, { v: 'tank', lab: 'Cell panel', title: 'Cell Panel', set: 'cells', msg: 'The containment cells open.' }),
      N(1000, 'Audio Log: Dr. Verran', '"Mira is gone. I\'ll bring her back. The door can reach any place, any time."', { kind2: 'audio', v: 'radio' }),
      Z(1350, 'pattern', { d: 2 }, { v: 'console', lab: 'Genome matrix', title: 'Genome Matrix', need: ['cells'], nm: 'The matrix console is locked.', set: 'genome', msg: 'The sequence resolves.' })]
  });
  lv('5-5', 'Core Access', 1800, 'lab', {
    req: ['shard'], zones: [[0, 1350], [1400, 1800]], dark: .42, steps: [['core', 'Stabilise the core relays', 'Light every relay node.'], ['shard', 'Take the shard', 'It is in the sealed core chamber.']],
    objects: [N(160, 'Final Entry', '"I removed Kai\'s memory so he would stop looking. He never did."', { kind2: 'msg', v: 'terminal' }), Z(780, 'circuit', { d: 3, w: 4, h: 3 }, { v: 'panel', lab: 'Core relays', title: 'Core Relays', set: 'core', msg: 'The core chamber opens.', sfx: 'power' }),
      PT(1200, [1450, 0], { lab: 'Enter core chamber', hide: 'core', v: 'hatch' }), PT(1450, [1200, 0], { lab: 'Back', hide: 'core', v: 'hatch' }), P(1640, SHARD(5, 2, 'Laboratory'), { v: 'pedestal', lab: 'Take the shard', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 6 : TEMPLE ============ */
  lv('6-1', 'Overgrown Gate', 1700, 'temple', {
    req: [], exitKey: 'stone_tablet', exitNm: 'A great stone gate with a tablet-shaped hollow.', dark: .56, steps: [['tablet', 'Find the stone tablet', 'Search the vine wall for three carved stones.']],
    objects: [N(170, 'Carved Warning', 'Three stones hold the tablet together: Star, Spiral, Rune. Find them in the vines.', { kind2: 'doc' }), Z(760, 'hidden', { items: ['star', 'spiral', 'rune'], n: 3, pal: ['#1a2214', '#2a3a1c', '#3a4a2a', '#222c18'] }, { v: 'crate', lab: 'Search vine wall', title: 'Vine Wall', give: it('stone_tablet', 'Stone Tablet', 'symbol', 'A carved stone tablet. It fits the gate.', { g: 'ankh' }), set: 'tablet', msg: 'The stones form a tablet.' })]
  });
  lv('6-2', 'Hall of Statues', 1900, 'temple', {
    req: ['statues'], dark: .56, steps: [['inscr', 'Read the wall inscription', 'The carvings on the wall.'], ['statues', 'Turn the statues to face the gate', 'Rotate the statues until all face up.']],
    objects: [IN(500, 'Wall Inscription', 'All guardians must look to the gate. Turning one disturbs the next.', { v: 'paper', oy: 30, lab: 'Read inscription', set: 'inscr' }), Z(1100, 'gears', { n: 5, pos: 4, skin: 'statue', d: 2 }, { v: 'statue', lab: 'Statue pedestal', title: 'The Guardians', set: 'statues', msg: 'The guardians turn to the gate. Stone grinds open.', sfx: 'machine' })]
  });
  lv('6-3', 'Pressure Corridor', 1900, 'temple', {
    req: ['plates'], dark: .56, steps: [['plates', 'Cross the plate corridor', 'Step on the plates in the right order.']],
    objects: [N(180, 'Carving', 'The order of the heavens, as the ancients saw it.', { kind2: 'doc' }), Z(1000, 'plates', { order: ['star', 'moon', 'sun', 'flame', 'eye'], d: 2 }, { v: 'plate', lab: 'Pressure plates', title: 'Ancient Plates', set: 'plates', msg: 'The corridor ahead opens.', sfx: 'machine' })]
  });
  lv('6-4', 'Whisper Wall', 1800, 'temple', {
    req: ['open'], dark: .6, steps: [['torch', 'Get a torch', 'Pick up the torch.'], ['lit', 'Light the brazier', 'Use the torch on the brazier.'], ['open', 'Wake the hidden wall', 'Tap the tiles on the wall until every light is on.']],
    objects: [P(300, it('torch', 'Torch', 'tool', 'An unlit torch.'), { v: 'loose', set: 'torch' }), LK(700, 'torch', { v: 'altar', lab: 'Brazier', need: ['torch'], nm: 'A cold brazier.', set: 'lit', msg: 'Flames leap up. Hidden carvings appear on the wall.' }),
      Z(1150, 'lights', { n: 3 }, { v: 'statue', lab: 'Hidden inscription', title: 'Hidden Inscription', hide: 'lit', set: 'open', msg: 'The wall trembles and opens.', sfx: 'door' })]
  });
  lv('6-5', 'Underground Chamber', 1900, 'temple', {
    req: ['shard'], zones: [[0, 1450], [1500, 1900]], dark: .6, steps: [['mech', 'Operate the ancient door', 'Match the symbols, then swap the tiles into order.'], ['shard', 'Take the shard', 'The pedestal in the chamber.']],
    objects: [Z(900, 'multi', { stages: [{ type: 'symbols', cfg: { glyphs: ['sun', 'moon', 'star', 'wave', 'flame'], col: '#e8d8a0' } }, { type: 'lights', cfg: { n: 3 } }] }, { v: 'altar', lab: 'Ancient door mechanism', title: 'Door Mechanism', set: 'mech', msg: 'The chamber opens.', sfx: 'machine' }),
      PT(1300, [1560, 0], { lab: 'Enter chamber', hide: 'mech', v: 'hatch' }), PT(1560, [1300, 0], { lab: 'Back', hide: 'mech', v: 'hatch' }), P(1740, SHARD(6, 9, 'Temple'), { v: 'pedestal', lab: 'Take the shard', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 7 : SKY ============ */
  lv('7-1', 'Broken Bridge', 1900, 'sky', {
    req: ['bridge'], dark: .05, plat: [{ x: 500, w: 100, hy: 45 }, { x: 640, w: 100, hy: 80 }, { x: 1100, w: 100, hy: 45 }, { x: 1230, w: 100, hy: 80 }, { x: 1450, w: 110, hy: 55 }],
    steps: [['have:crystal:3', 'Collect three energy crystals', 'Climb the floating stones.'], ['bridge', 'Power the pylon', 'Place the crystals in the pylon.']],
    objects: [P(640, it('crystal', 'Energy Crystal', 'crystal', 'A humming crystal.', { stack: true }), { v: 'crystal', hy: 80, id: 'c1' }), P(1230, it('crystal', 'Energy Crystal', 'crystal', 'A humming crystal.', { stack: true }), { v: 'crystal', hy: 80, id: 'c2' }), P(1450, it('crystal', 'Energy Crystal', 'crystal', 'A humming crystal.', { stack: true }), { v: 'crystal', hy: 55, id: 'c3' }),
      LK(1750, 'crystal', { n: 3, v: 'pylon', lab: 'Pylon', set: 'bridge', msg: 'The bridge flickers into existence.', sfx: 'power' })]
  });
  lv('7-2', 'Wind Terrace', 1800, 'sky', {
    req: ['wind'], dark: .05, steps: [['wind', 'Redirect the wind', 'Flip the deflectors to push the wind into the turbine.']],
    objects: [N(170, 'Weathered Note', 'The turbine wakes only if the wind arrives from the left.', { kind2: 'doc' }), Z(1000, 'mirror', { d: 2, skin: 'wind' }, { v: 'console', lab: 'Deflector controls', title: 'Wind Deflectors', set: 'wind', msg: 'The turbine whirls.', sfx: 'machine' })]
  });
  lv('7-3', 'Gravity Hall', 1900, 'sky', {
    req: ['grav'], dark: .05, steps: [['grav', 'Stabilise the gravity cores', 'Light every core node.']],
    objects: [N(170, 'Fortress Log', 'When the cores fail, the floors drift. Bring them to full power.', { kind2: 'doc' }), Z(1000, 'circuit', { d: 2, w: 3, h: 4, c: '#ffd36a' }, { v: 'panel', lab: 'Gravity cores', title: 'Gravity Cores', set: 'grav', msg: 'Gravity returns.', sfx: 'power' })]
  });
  lv('7-4', 'Moving Platforms', 2300, 'sky', {
    req: ['open'], dark: .05, intro: ['Kai: Those platforms are moving. Time the jump.'],
    plat: [{ x: 800, w: 90, hy: 65, mv: { ax: 0, ay: 42, sp: 1.1 } }, { x: 905, w: 110, hy: 100 }, { x: 1500, w: 90, hy: 65, mv: { ax: 0, ay: 42, sp: 1.3 } }, { x: 1605, w: 110, hy: 100 }],
    steps: [['have:crystal:2', 'Collect two crystals', 'Ride the lifts up to the high ledges.'], ['open', 'Open the sky gate', 'Put them in the pylon.']],
    objects: [P(905, it('crystal', 'Energy Crystal', 'crystal', 'A humming crystal.', { stack: true }), { v: 'crystal', hy: 100, id: 'c1' }), P(1605, it('crystal', 'Energy Crystal', 'crystal', 'A humming crystal.', { stack: true }), { v: 'crystal', hy: 100, id: 'c2' }), LK(2100, 'crystal', { n: 2, v: 'pylon', lab: 'Pylon', set: 'open', msg: 'The sky gate opens.', sfx: 'power' })]
  });
  lv('7-5', 'Sky Throne', 1900, 'sky', {
    req: ['shard'], dark: .05, steps: [['code', 'Read the throne inscription', 'The numbers on the throne.'], ['shard', 'Open the throne and take the shard', 'Turn the gears, then swap the tiles into order.']],
    objects: [N(300, 'Throne Inscription', 'Four winds, four crowns, two stars, one sun: 4 4 2 1.', { kind2: 'doc' }), Z(800, 'gears', { n: 4, pos: 4 }, { v: 'safe', lab: 'Open throne seat', title: 'Throne Seat', set: 'code', msg: 'The seat slides away.', sfx: 'unlock' }),
      Z(1200, 'swap', { n: 5 }, { v: 'altar', lab: 'Sky altar', title: 'Sky Altar', need: ['code'], nm: 'The altar is sealed.', set: 'open2', msg: 'The altar opens.' }), P(1600, SHARD(7, 4, 'Sky Fortress'), { v: 'pedestal', lab: 'Take the shard', need: ['open2'], nm: 'The shard is sealed in the altar.', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 8 : DREAM ============ */
  lv('8-1', 'Shifting Rooms', 1900, 'dream', {
    req: ['open'], dark: .3, steps: [['key', 'Shift reality to find the key', 'Use the shifter. Some things only exist in the other reality.'], ['open', 'Use the key on the door', 'The door appears in the first reality.']],
    objects: [Object.assign({ k: 'switch', x: 400, set: 'shift', toggle: true, v: 'shifter', lab: 'Shift reality', msg: 'The world shifts.', sfx: 'portal' }, {}),
      P(900, it('dream_key', 'Dream Key', 'key', 'A key that only exists on the other side.'), { world: 'b', v: 'loose', lab: 'Take key', set: 'key' }), IN(1300, 'Reality Note', 'Some doors only exist in one version of the room.', { world: 'a', v: 'paper', lab: 'Read note' }),
      LK(1550, 'dream_key', { world: 'a', v: 'panel', oy: 40, lab: 'Dream lock', set: 'open', msg: 'The dream door unlocks.', sfx: 'unlock' })]
  });
  lv('8-2', 'Illusion Gallery', 1800, 'dream', {
    req: ['ill2'], dark: .3, steps: [['ill1', 'Find the odd piece in the first illusion', 'Which shape completes the pattern?'], ['ill2', 'Solve the second illusion', 'The harder pattern.']],
    objects: [Z(650, 'pattern', { d: 1 }, { v: 'painting', lab: 'First illusion', title: 'First Illusion', set: 'ill1', msg: 'The picture sharpens.' }), Z(1150, 'pattern', { d: 2 }, { v: 'painting', lab: 'Second illusion', title: 'Second Illusion', need: ['ill1'], nm: 'Solve the first one first.', set: 'ill2', msg: 'The illusion shatters.' })]
  });
  lv('8-3', 'Mirror Hall', 1900, 'dream', {
    req: ['mir'], dark: .3, steps: [['mir', 'Align the mirror beams', 'Flip mirrors to guide the beam to the target.']],
    objects: [IN(300, 'Your Reflection', 'Your reflection smiles half a second too late.', { v: 'mirror', lab: 'Look in mirror' }), Z(1000, 'mirror', { d: 2, skin: 'mirror' }, { v: 'mirror', lab: 'Mirror array', title: 'Mirror Array', set: 'mir', msg: 'The mirrors align. The way opens.', sfx: 'portal' })]
  });
  lv('8-4', 'Portal Maze', 2000, 'dream', {
    req: ['out'], zones: [[0, 900], [950, 1500], [1550, 2000]], dark: .3, intro: ['Kai: Three portals. Only one of them goes forward.'], steps: [['out', 'Find the way through the maze', 'Violet leads onward. Red and green loop back.']],
    objects: [N(160, 'Whisper', 'Three doors, one truth: follow the violet light.', { kind2: 'letter' }), PT(500, [200, 0], { col: '#ff7a7a', lab: 'Red portal' }), PT(650, [150, 0], { col: '#7aff9a', lab: 'Green portal' }), PT(800, [1000, 0], { col: '#b57aff', lab: 'Violet portal' }),
      N(1050, 'Whisper', 'Again: the violet door. The red one only takes you home.', { kind2: 'letter' }), PT(1150, [250, 0], { col: '#ff7a7a', lab: 'Red portal' }), PT(1300, [1620, 0], { col: '#b57aff', lab: 'Violet portal' }),
      SW(1800, 'out', { lab: 'Pull the lever', msg: 'The maze unravels.', sfx: 'machine' })]
  });
  lv('8-5', 'The Impossible Stair', 1800, 'dream', {
    req: ['shard'], dark: .32, steps: [['stair', 'Climb the impossible stair', 'Solve the three puzzles.'], ['shard', 'Take the shard', 'It hangs at the top.']],
    objects: [Z(900, 'multi', { stages: [{ type: 'pattern', cfg: { d: 2 } }, { type: 'slide', cfg: { n: 3, g: 'spiral', c1: '#a03aa0' } }, { type: 'swap', cfg: { n: 5 } }] }, { v: 'altar', lab: 'Impossible stair', title: 'The Impossible Stair', set: 'stair', msg: 'The stair opens.', sfx: 'portal' }), P(1500, SHARD(8, 7, 'Dream World'), { v: 'pedestal', lab: 'Take the shard', need: ['stair'], nm: 'It is out of reach.', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 9 : SPACE ============ */
  lv('9-1', 'Airlock Corridor', 1800, 'space', {
    req: ['open'], dark: .38, steps: [['badge', 'Find a crew badge', 'Take it from the locker.'], ['scan', 'Scan the crew badge', 'Use the scanner.'], ['open', 'Open the airlock', 'Aim the mirror beam at the receiver.']],
    objects: [N(170, 'Crew Roster', 'Commander 7 - Pilot 7 - Medic 3 - Engineer 1: the airlock code follows the roster.', { kind2: 'doc' }), P(450, it('crew_badge', 'Crew Badge', 'card', 'A scuffed crew badge.'), { v: 'locker', lab: 'Open locker', set: 'badge' }), LK(800, 'crew_badge', { use: false, v: 'panel', lab: 'Badge scanner', need: ['badge'], nm: 'A scanner.', set: 'scan', msg: 'Badge accepted.' }),
      Z(1200, 'mirror', { d: 1, skin: 'laser' }, { v: 'keypad', lab: 'Airlock keypad', title: 'Airlock Keypad', need: ['scan'], nm: 'Scan your badge first.', set: 'open', msg: 'The airlock cycles open.', sfx: 'door' })]
  });
  lv('9-2', 'Observation Deck', 1800, 'space', {
    req: ['sys'], dark: .38, steps: [['sys', 'Wake the station computer', 'Complete the pattern on the computer.']],
    objects: [N(300, 'Captain\'s Log', 'I named the station for the hunter in the stars - the three belt stars we see from the deck. The old computer only answers to a steady eye: match the pattern to wake it.', { kind2: 'audio', v: 'radio' }), Z(1100, 'pattern', { d: 2 }, { v: 'terminal', lab: 'Computer', title: 'Station Computer', set: 'sys', msg: 'Access granted.', sfx: 'power' })]
  });
  lv('9-3', 'Reactor Core', 1900, 'space', {
    req: ['energy'], dark: .4, steps: [['energy', 'Distribute reactor energy', 'Light every node.']],
    objects: [N(170, 'Reactor Note', 'The reactor must be balanced across all conduits.', { kind2: 'doc' }), Z(1000, 'circuit', { d: 3, w: 4, h: 4 }, { v: 'console', lab: 'Reactor console', title: 'Energy Distribution', set: 'energy', msg: 'The reactor stabilises.', sfx: 'power' })]
  });
  lv('9-4', 'Oxygen Plant', 1900, 'space', {
    req: ['oxygen'], dark: .4, steps: [['wrench', 'Find the wrench', 'On the work bench.'], ['bolt', 'Loosen the access panel', 'Use the wrench.'], ['oxygen', 'Restore oxygen flow', 'Connect the pipes.']],
    objects: [P(320, it('wrench2', 'Spanner', 'tool', 'A station spanner.'), { v: 'desk', set: 'wrench' }), LK(700, 'wrench2', { v: 'panel', oy: 30, lab: 'Access panel', need: ['wrench'], nm: 'Bolted shut.', set: 'bolt', msg: 'The panel opens.' }),
      Z(1150, 'pipes', { d: 2, skin: 'oxygen' }, { v: 'panel', lab: 'Oxygen conduit', title: 'Oxygen Conduit', need: ['bolt'], nm: 'Locked behind the panel.', set: 'oxygen', msg: 'Oxygen flows again.', sfx: 'water' })]
  });
  lv('9-5', 'Gravity Control', 2000, 'space', {
    req: ['shard'], lowG: true, dark: .4, plat: [{ x: 1350, w: 200, hy: 170 }],
    steps: [['lowg', 'Switch gravity to low', 'Pull the gravity lever. You can toggle it back.'], ['shard', 'Reach the high platform and take the shard', 'Jump high.']],
    objects: [N(170, 'Station Manual', 'Low gravity lets you reach high decks.', { kind2: 'doc' }), SW(600, 'lowg', { toggle: true, lab: 'Gravity lever', msg: 'Gravity shifts.', sfx: 'machine' }), P(1350, SHARD(9, 5, 'Space Station'), { v: 'pedestal', hy: 170, lab: 'Take the shard', set: 'shard', sfx: 'crystal' })]
  });
  /* ============ CHAPTER 10 : FINAL ============ */
  lv('10-1', 'Threshold Corridor', 1800, 'final', {
    req: ['a1', 'a2', 'a3'], dark: .5, steps: [['a1', 'Place the Mansion shard', ''], ['a2', 'Place the Dark City shard', ''], ['a3', 'Place the Sewer shard', '']],
    objects: [N(160, 'Wall Carving', 'Nine shards, nine memories. Place them in order.', { kind2: 'doc' }), LK(600, 'shard1', { use: false, v: 'altar', g: 'key', lab: 'Alcove one', set: 'a1', msg: 'The first alcove glows.' }), LK(950, 'shard2', { use: false, v: 'altar', g: 'sun', lab: 'Alcove two', set: 'a2', msg: 'The second alcove glows.' }), LK(1300, 'shard3', { use: false, v: 'altar', g: 'drop', lab: 'Alcove three', set: 'a3', msg: 'The third alcove glows.' })]
  });
  lv('10-2', 'Hall of Echoes', 1900, 'final', {
    req: ['echo'], dark: .5, steps: [['echo', 'Match the echoes', 'Match symbols, then swap the tiles into order.']],
    objects: [N(160, 'Whisper', '"Kai... remember."', { kind2: 'letter' }), Z(1000, 'multi', { stages: [{ type: 'symbols', cfg: { glyphs: ['atom', 'ankh', 'crown', 'eye', 'star', 'gear'] } }, { type: 'lights', cfg: { n: 3 } }] }, { v: 'altar', lab: 'Echo stone', title: 'Echo Stone', set: 'echo', msg: 'The echoes fall silent.', sfx: 'machine' })]
  });
  lv('10-3', 'The Mechanism', 2000, 'final', {
    req: ['mech'], dark: .5, steps: [['gear', 'Align the great gears', 'Align every marker.'], ['mech', 'Power the relays', 'Light every node.']],
    objects: [Z(700, 'gears', { n: 6, pos: 4, d: 3 }, { v: 'machine', lab: 'Great gears', title: 'The Great Gears', set: 'gear', msg: 'The gears mesh.', sfx: 'machine' }), Z(1300, 'circuit', { d: 3, w: 4, h: 4 }, { v: 'panel', lab: 'Relay bank', title: 'Relay Bank', need: ['gear'], nm: 'Align the gears first.', set: 'mech', msg: 'The mechanism hums.', sfx: 'power' })]
  });
  lv('10-4', 'The Antechamber', 1800, 'final', {
    req: ['open'], dark: .5, steps: [['open', 'Open the antechamber door', 'Slide the blocks into place to open the door.']],
    objects: [N(300, 'Carved Command', 'Four shards open this door: the Mansion, the Factory, the Temple and the Station - in that order. Read their numbers.', { kind2: 'doc' }), Z(1000, 'slide', { n: 3, g: 'key', c1: '#3a7aa0' }, { v: 'keypad', lab: 'Antechamber lock', title: 'Antechamber Lock', set: 'open', msg: 'The antechamber opens.', sfx: 'door' })]
  });
  lv('10-5', 'The Final Room', 2200, 'final', {
    req: ['final'], ringX: 1500, dark: .5, steps: [['final', 'Activate the central mechanism', 'Combine everything you have learned.']],
    objects: [N(300, 'Last Instruction', 'The central mechanism: use the City, the Laboratory and the Dream, in that order.', { kind2: 'doc' }), Z(1500, 'multi', { stages: [{ type: 'pipes', cfg: { d: 2 } }, { type: 'swap', cfg: { n: 5 } }, { type: 'pattern', cfg: { d: 2 } }, { type: 'mirror', cfg: { d: 2, skin: 'laser' } }, { type: 'lights', cfg: { n: 3 } }] }, { v: 'altar', lab: 'Central mechanism', title: 'Central Mechanism', set: 'final', msg: 'The central door opens.', sfx: 'machine' })]
  });
  TLR.CHAPTERS = CH; TLR.LEVELS = L;
  TLR.getLevel = id => L.find(l => l.id === id);
  TLR.levelIndex = id => L.findIndex(l => l.id === id);
})(window);
