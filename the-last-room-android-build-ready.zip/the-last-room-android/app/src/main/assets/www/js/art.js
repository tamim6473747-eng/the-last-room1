/* THE LAST ROOM - art helpers: utilities, glyph library, item icons */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const TAU = Math.PI * 2;
  const U = TLR.U = {
    TAU,
    clamp: (v, a, b) => v < a ? a : v > b ? b : v,
    lerp: (a, b, t) => a + (b - a) * t,
    rnd(seed) { let a = seed >>> 0; return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; },
    hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; },
    rr(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); },
    lg(c, x0, y0, x1, y1, st) { const g = c.createLinearGradient(x0, y0, x1, y1); st.forEach(s => g.addColorStop(s[0], s[1])); return g; },
    rg(c, x, y, r0, r1, st) { const g = c.createRadialGradient(x, y, r0, x, y, r1); st.forEach(s => g.addColorStop(s[0], s[1])); return g; },
    mk(w, h) { const cv = document.createElement('canvas'); cv.width = Math.max(1, w | 0); cv.height = Math.max(1, h | 0); return cv; },
    shuffle(a, r) { r = r || Math.random; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  };
  /* ---------- glyph library (symbols used by puzzles and items) ---------- */
  const GL = {
    sun(c, s) { c.beginPath(); c.arc(0, 0, s * .32, 0, TAU); for (let i = 0; i < 8; i++) { const a = i * TAU / 8; c.moveTo(Math.cos(a) * s * .46, Math.sin(a) * s * .46); c.lineTo(Math.cos(a) * s * .78, Math.sin(a) * s * .78); } c.stroke(); },
    moon(c, s) { c.beginPath(); c.moveTo(s * .2, -s * .7); c.bezierCurveTo(-s * .95, -s * .5, -s * .95, s * .5, s * .2, s * .7); c.bezierCurveTo(-s * .4, s * .35, -s * .4, -s * .35, s * .2, -s * .7); c.stroke(); },
    star(c, s) { c.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? s * .3 : s * .72; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.stroke(); },
    wave(c, s) { for (let k = -1; k <= 1; k++) { c.beginPath(); for (let i = 0; i <= 20; i++) { const x = -s * .7 + i * s * 1.4 / 20; const y = k * s * .3 + Math.sin(i / 20 * TAU * 1.5) * s * .12; i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); } },
    flame(c, s) { c.beginPath(); c.moveTo(0, -s * .8); c.bezierCurveTo(s * .55, -s * .2, s * .6, s * .35, 0, s * .72); c.bezierCurveTo(-s * .6, s * .35, -s * .5, -s * .1, -s * .1, -s * .35); c.bezierCurveTo(-s * .1, -s * .55, 0, -s * .6, 0, -s * .8); c.stroke(); },
    leaf(c, s) { c.beginPath(); c.moveTo(-s * .6, s * .6); c.bezierCurveTo(-s * .7, -s * .5, s * .2, -s * .8, s * .65, -s * .7); c.bezierCurveTo(s * .7, -s * .1, s * .3, s * .6, -s * .6, s * .6); c.moveTo(-s * .6, s * .6); c.lineTo(s * .3, -s * .3); c.stroke(); },
    eye(c, s) { c.beginPath(); c.moveTo(-s * .8, 0); c.quadraticCurveTo(0, -s * .75, s * .8, 0); c.quadraticCurveTo(0, s * .75, -s * .8, 0); c.moveTo(s * .24, 0); c.arc(0, 0, s * .24, 0, TAU); c.stroke(); },
    key(c, s) { c.beginPath(); c.arc(-s * .42, 0, s * .26, 0, TAU); c.moveTo(-s * .16, 0); c.lineTo(s * .75, 0); c.moveTo(s * .5, 0); c.lineTo(s * .5, s * .3); c.moveTo(s * .72, 0); c.lineTo(s * .72, s * .22); c.stroke(); },
    atom(c, s) { for (let i = 0; i < 3; i++) { c.save(); c.rotate(i * Math.PI / 3); c.beginPath(); c.ellipse(0, 0, s * .78, s * .3, 0, 0, TAU); c.stroke(); c.restore(); } c.beginPath(); c.arc(0, 0, s * .1, 0, TAU); c.fill(); },
    flask(c, s) { c.beginPath(); c.moveTo(-s * .18, -s * .75); c.lineTo(s * .18, -s * .75); c.lineTo(s * .18, -s * .2); c.lineTo(s * .62, s * .65); c.lineTo(-s * .62, s * .65); c.lineTo(-s * .18, -s * .2); c.closePath(); c.moveTo(-s * .4, s * .25); c.lineTo(s * .4, s * .25); c.stroke(); },
    bolt(c, s) { c.beginPath(); c.moveTo(s * .2, -s * .8); c.lineTo(-s * .4, s * .1); c.lineTo(0, s * .1); c.lineTo(-s * .2, s * .8); c.lineTo(s * .45, -s * .15); c.lineTo(s * .05, -s * .15); c.closePath(); c.stroke(); },
    dna(c, s) { for (const ph of [0, Math.PI]) { c.beginPath(); for (let i = 0; i <= 20; i++) { const y = -s * .75 + i * s * 1.5 / 20, x = Math.sin(i / 20 * TAU + ph) * s * .35; i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); } c.beginPath(); for (let i = 1; i < 6; i++) { const y = -s * .75 + i * s * 1.5 / 6, x = Math.sin(i / 6 * TAU) * s * .35; c.moveTo(-x, y); c.lineTo(x, y); } c.stroke(); },
    magnet(c, s) { c.beginPath(); c.moveTo(-s * .5, -s * .6); c.lineTo(-s * .5, s * .1); c.arc(0, s * .1, s * .5, Math.PI, 0, true); c.lineTo(s * .5, -s * .6); c.moveTo(-s * .5, -s * .35); c.lineTo(-s * .2, -s * .35); c.moveTo(s * .5, -s * .35); c.lineTo(s * .2, -s * .35); c.stroke(); },
    spiral(c, s) { c.beginPath(); for (let i = 0; i <= 60; i++) { const a = i / 60 * TAU * 2.5, r = s * .08 + i / 60 * s * .65; const x = Math.cos(a) * r, y = Math.sin(a) * r; i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); },
    tri(c, s) { c.beginPath(); c.moveTo(0, -s * .75); c.lineTo(s * .7, s * .55); c.lineTo(-s * .7, s * .55); c.closePath(); c.moveTo(s * .14, s * .05); c.arc(0, s * .05, s * .14, 0, TAU); c.stroke(); },
    ankh(c, s) { c.beginPath(); c.ellipse(0, -s * .38, s * .25, s * .3, 0, 0, TAU); c.moveTo(0, -s * .08); c.lineTo(0, s * .75); c.moveTo(-s * .4, s * .15); c.lineTo(s * .4, s * .15); c.stroke(); },
    gear(c, s) { c.beginPath(); for (let i = 0; i < 16; i++) { const a = i * TAU / 16, r = i % 2 ? s * .52 : s * .72; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.moveTo(s * .2, 0); c.arc(0, 0, s * .2, 0, TAU); c.stroke(); },
    crown(c, s) { c.beginPath(); c.moveTo(-s * .7, s * .5); c.lineTo(-s * .7, -s * .3); c.lineTo(-s * .3, s * .05); c.lineTo(0, -s * .55); c.lineTo(s * .3, s * .05); c.lineTo(s * .7, -s * .3); c.lineTo(s * .7, s * .5); c.closePath(); c.stroke(); },
    rune(c, s) { c.beginPath(); c.moveTo(-s * .3, -s * .75); c.lineTo(-s * .3, s * .75); c.moveTo(-s * .3, -s * .3); c.lineTo(s * .45, -s * .75); c.moveTo(-s * .3, s * .1); c.lineTo(s * .45, -s * .35); c.moveTo(-s * .3, s * .5); c.lineTo(s * .45, s * .1); c.stroke(); },
    drop(c, s) { c.beginPath(); c.moveTo(0, -s * .8); c.bezierCurveTo(s * .6, -s * .1, s * .6, s * .6, 0, s * .65); c.bezierCurveTo(-s * .6, s * .6, -s * .6, -s * .1, 0, -s * .8); c.stroke(); }
  };
  U.GLYPHS = Object.keys(GL);
  U.GNAME = { sun: 'Sun', moon: 'Moon', star: 'Star', wave: 'Waves', flame: 'Flame', leaf: 'Leaf', eye: 'Eye', key: 'Key', atom: 'Atom', flask: 'Flask', bolt: 'Lightning', dna: 'Helix', magnet: 'Magnet', spiral: 'Spiral', tri: 'Pyramid', ankh: 'Ankh', gear: 'Cog', crown: 'Crown', rune: 'Rune', drop: 'Droplet' };
  U.glyph = function (c, name, x, y, s, col, lw) {
    c.save(); c.translate(x, y); c.strokeStyle = col || '#fff'; c.fillStyle = col || '#fff'; c.lineWidth = lw || Math.max(1.5, s / 11); c.lineCap = 'round'; c.lineJoin = 'round';
    (GL[name] || GL.rune)(c, s); c.restore();
  };
  /* ---------- item icons (rendered once to data URLs) ---------- */
  const iconCache = {}, canvCache = {};
  const PAL = { key: '#e0b95a', note: '#d9cfae', photo: '#9fb6c9', battery: '#7fd16c', tool: '#b9c0c9', symbol: '#c58cff', card: '#6fc7ff', comp: '#e89a52', special: '#ff6f7a', audio: '#8de0c9', msg: '#7fe3ff', shard: '#ff8a5c', crystal: '#7ae7ff', doc: '#e7d8a8' };
  U.itemIcon = function (it) {
    const k = it.id; if (iconCache[k]) return iconCache[k];
    const cv = U.mk(96, 96), c = cv.getContext('2d'); c.scale(1.5, 1.5);
    const col = it.col || PAL[it.type] || '#ddd';
    c.fillStyle = U.rg(c, 32, 28, 4, 48, [[0, 'rgba(255,255,255,.12)'], [1, 'rgba(0,0,0,0)']]); c.fillRect(0, 0, 64, 64);
    c.save(); c.translate(32, 32); c.lineCap = 'round'; c.lineJoin = 'round';
    c.shadowColor = col; c.shadowBlur = 8;
    const stroke = (w, s) => { c.lineWidth = w; c.strokeStyle = s || '#1a1410'; c.stroke(); };
    switch (it.type) {
      case 'key': c.rotate(-.6); c.fillStyle = col; c.beginPath(); c.arc(-14, 0, 9, 0, TAU); c.arc(-14, 0, 4, 0, TAU, true); c.fill('evenodd'); c.fillRect(-6, -2.5, 28, 5); c.fillRect(14, 0, 4, 9); c.fillRect(21, 0, 4, 6); if (it.half) { c.fillStyle = '#0008'; c.fillRect(2, -5, 14, 10); } break;
      case 'note': case 'doc': c.rotate(.1); c.fillStyle = col; U.rr(c, -16, -20, 32, 40, 3); c.fill(); stroke(1.5); c.strokeStyle = '#6b5a38'; c.lineWidth = 1.4; for (let i = 0; i < 5; i++) { c.beginPath(); c.moveTo(-10, -12 + i * 7); c.lineTo(10 - (i % 2) * 5, -12 + i * 7); c.stroke(); } break;
      case 'photo': c.rotate(-.1); c.fillStyle = '#eee'; U.rr(c, -19, -20, 38, 42, 2); c.fill(); c.fillStyle = '#35516b'; c.fillRect(-15, -16, 30, 26); c.fillStyle = '#7fa5c6'; c.beginPath(); c.arc(-3, -6, 5, 0, TAU); c.fill(); c.fillRect(-9, -1, 12, 11); c.fillStyle = '#2a2f3a'; c.fillRect(3, 2, 10, 8); break;
      case 'battery': c.fillStyle = '#2a2d34'; U.rr(c, -9, -17, 18, 34, 3); c.fill(); stroke(1.5, '#000'); c.fillStyle = col; c.fillRect(-7, -9, 14, 20); c.fillStyle = '#ccc'; c.fillRect(-3, -21, 6, 5); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(2, -6); c.lineTo(-4, 3); c.lineTo(0, 3); c.lineTo(-2, 10); c.lineTo(4, 1); c.lineTo(0, 1); c.fill(); break;
      case 'tool': c.rotate(.7); c.fillStyle = col; c.fillRect(-3, -6, 6, 26); c.beginPath(); c.arc(0, -12, 9, 0, TAU); c.fill(); c.fillStyle = '#10131a'; c.fillRect(-3.5, -24, 7, 12); break;
      case 'symbol': c.fillStyle = '#2b2140'; c.beginPath(); c.arc(0, 0, 21, 0, TAU); c.fill(); stroke(2, col); U.glyph(c, it.g || 'rune', 0, 0, 28, col, 2.4); break;
      case 'card': c.fillStyle = '#1d2a3a'; U.rr(c, -22, -14, 44, 28, 4); c.fill(); stroke(1.6, col); c.fillStyle = col; c.fillRect(-18, -8, 12, 9); c.fillRect(-18, 5, 30, 3); c.globalAlpha = .6; c.fillRect(2, -8, 16, 3); break;
      case 'comp': c.fillStyle = col; c.beginPath(); for (let i = 0; i < 16; i++) { const a = i * TAU / 16, r = i % 2 ? 14 : 20; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); stroke(1.6); c.fillStyle = '#2a1a10'; c.beginPath(); c.arc(0, 0, 6, 0, TAU); c.fill(); break;
      case 'shard': case 'crystal': c.fillStyle = col; c.beginPath(); c.moveTo(0, -23); c.lineTo(13, -4); c.lineTo(8, 20); c.lineTo(-9, 20); c.lineTo(-14, -2); c.closePath(); c.fill(); c.fillStyle = 'rgba(255,255,255,.4)'; c.beginPath(); c.moveTo(0, -23); c.lineTo(-14, -2); c.lineTo(-2, 6); c.closePath(); c.fill(); stroke(1.4, '#fff8'); if (it.g) U.glyph(c, it.g, 0, 5, 12, '#2a1208', 1.6); break;
      case 'audio': c.fillStyle = '#30343c'; U.rr(c, -20, -13, 40, 26, 4); c.fill(); stroke(1.4, col); c.fillStyle = col; c.beginPath(); c.arc(-9, 0, 6, 0, TAU); c.arc(9, 0, 6, 0, TAU); c.fill(); c.fillStyle = '#10131a'; c.beginPath(); c.arc(-9, 0, 2, 0, TAU); c.arc(9, 0, 2, 0, TAU); c.fill(); break;
      case 'msg': c.fillStyle = '#10222c'; U.rr(c, -21, -16, 42, 30, 3); c.fill(); stroke(1.6, col); c.fillStyle = col; for (let i = 0; i < 4; i++) c.fillRect(-16, -10 + i * 6, 22 - (i % 2) * 8, 2.4); c.fillRect(-8, 17, 16, 3); break;
      default: c.fillStyle = col; c.beginPath(); c.moveTo(0, -20); c.lineTo(18, 0); c.lineTo(0, 20); c.lineTo(-18, 0); c.closePath(); c.fill(); stroke(1.6); if (it.g) U.glyph(c, it.g, 0, 0, 16, '#220', 1.6);
    }
    c.restore();
    canvCache[k] = cv; return iconCache[k] = cv.toDataURL();
  };
  U.itemCanvas = function (it) { U.itemIcon(it); return canvCache[it.id]; };
})(window);
