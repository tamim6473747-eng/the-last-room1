/* THE LAST ROOM - the haunting: a ghost visits now and then. Survive by hiding in wardrobes/lockers, blinding it with the lantern (Light button / F), or simply outrunning it. */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {}, U = TLR.U, TAU = Math.PI * 2, A = () => TLR.Audio;
  const R = (a, b) => a + Math.random() * (b - a);
  const DIFF = { easy: { sp: .84, iv: 1.45, hunt: .8 }, normal: { sp: 1, iv: 1, hunt: 1 }, hard: { sp: 1.13, iv: .7, hunt: 1.1 } };
  const TYPES = { 1: 'wailer', 2: 'wailer', 3: 'sensor', 4: 'watcher', 5: 'seeker', 6: 'wailer', 7: 'watcher', 8: 'sensor', 9: 'seeker', 10: 'mix' };
  const Ghost = TLR.Ghost = {
    enabled: true, s: null, fear: 0, flashT: 0, cd: 0, over: 0, beatT: 0, shake: 0,
    D() { return DIFF[(TLR.Save.settings.diff) || 'normal'] || DIFF.normal; },
    vib(p) { try { if (TLR.Save.settings.vib !== 'off' && navigator.vibrate) navigator.vibrate(p); } catch (e) { } },
    pickType() { const L = TLR.Game.L, t = (L && L.ghost) || TYPES[L ? L.ch : 1] || 'wailer'; return t === 'mix' ? ['wailer', 'sensor', 'watcher', 'seeker'][Math.floor(Math.random() * 4)] : t; },
    /* the player (or something) made a sound at x: sensing ghosts follow it */
    noise(x, r) { const s = this.s; if (!s || !this.enabled || s.type !== 'sensor') return; if (s.st === 'hunt' || s.st === 'warn') { if (Math.abs(s.x - x) < r + 300) { s.tx = x; s.heard = 0; } } },
    reset() { const G = TLR.Game, L = G.L; this.tut = !!(L && L.id === '1-1' && !TLR.Save.data.tut); this.tip = 0; this.s = { st: 'idle', x: 0, a: 0, t: this.tut ? 11 : (L && L.boss ? 8 : R(20, 30)), face: 1, hunt: 0, stun: 0, type: 'wailer' }; this.fear = 0; this.flashT = 0; this.cd = 0; this.over = 0; this.shake = 0; G.p.hidden = null; this.enabled = !G.qa && !(L && L.noGhost); },
    chap() { const L = TLR.Game.L; return L ? L.ch : 1; },
    speed() { const L = TLR.Game.L, s = this.s, ty = s && s.type; return (92 + this.chap() * 4) * this.D().sp * (L && L.boss ? 1.14 : 1) * (this.tut ? .62 : 1) * (ty === 'watcher' ? 1.3 : ty === 'sensor' ? .95 : 1); },
    /* called every frame while playing */
    update(dt) {
      const G = TLR.Game, p = G.p, s = this.s, L = G.L; if (!s || !this.enabled) return;
      this.flashT = Math.max(0, this.flashT - dt); this.tip = Math.max(0, this.tip - dt); const lb = document.getElementById('tb-light'); if (lb) lb.classList.toggle('tip', this.tip > 0 && this.cd <= 0); this.cd = Math.max(0, this.cd - dt); this.shake = Math.max(0, this.shake - dt);
      if (G.blocked() || G.act && G.act.name === 'solve') { this.fear = Math.max(0, this.fear - dt); return; }
      const face = p.face;
      if (s.st === 'idle') { s.t -= dt; this.fear = Math.max(0, this.fear - dt * .6); if (s.t <= 0 && !p.hidden) this.spawn(); else if (s.t <= 0) s.t = 6; return; }
      s.a = Math.min(1, s.a + dt * .8);
      const dx = p.x - s.x; s.face = dx >= 0 ? 1 : -1;
      if (s.st === 'warn') { s.t -= dt; this.fear = Math.min(1, this.fear + dt * .5); if (s.t <= 0) { s.st = 'hunt'; s.hunt = 0; A().sfx('whisper'); } return; }
      if (s.st === 'hunt') {
        s.hunt += dt; s.heard = (s.heard || 0) + dt; let tx = p.hidden ? p.hidden.x : p.x;
        if (s.type === 'sensor' && !p.hidden) { if (s.tx == null) s.tx = p.x; tx = s.tx; if (Math.abs(p.x - s.x) > 150 && Math.abs(tx - s.x) < 14) { s.wander = (s.wander || 0) + dt; tx = s.x + Math.sin(s.wander * 1.4) * 120; if (s.wander > 7) { s.st = 'leave'; s.t = 1.4; s.wander = 0; return; } } }
        let frozen = false; if (s.type === 'watcher' && !p.hidden && (p.x - s.x) * p.face < 0 && Math.abs(p.x - s.x) < 700) frozen = true; s.frozen = frozen;
        const d = tx - s.x; if (!frozen) { s.x += Math.sign(d) * Math.min(Math.abs(d), this.speed() * dt); s.x = Math.max(10, Math.min(L.w - 10, s.x)); }
        const near = Math.abs(p.x - s.x); this.fear = Math.min(1, Math.max(this.fear, 1 - near / 520));
        this.beatT -= dt; if (this.beatT <= 0) { A().sfx('beat'); if (near < 300) this.vib(50); this.beatT = .35 + Math.min(.9, near / 600); }
        if (p.hidden) { if (Math.abs(p.hidden.x - s.x) < 34) { s.st = 'sniff'; s.t = 5.5; A().sfx('creak'); } }
        else if (!frozen && near < 26 && p.y > G.floorY - 70) { this.kill(); return; }
        if (s.hunt > (L.boss ? 60 : 22 * this.D().hunt)) { s.st = 'leave'; s.t = 1.4; }
        return;
      }
      if (s.st === 'found') { s.t -= dt; this.shake = .12; this.fear = 1; if (!p.hidden) { s.st = 'hunt'; s.hunt = 0; return; } if (s.t <= 0) { this.kill(); } return; }
      if (s.st === 'sniff') { s.t -= dt; this.shake = .1; this.fear = Math.min(1, this.fear + dt * .1); if (!p.hidden) { s.st = 'hunt'; s.hunt = 0; return; } if (s.t <= 0) { if (s.type === 'seeker' && Math.random() < (TLR.Save.settings.diff === 'easy' ? .35 : .65)) { s.st = 'found'; s.t = 1.7; A().sfx('scare'); this.vib([120, 60, 120]); TLR.UI.toast('It found you! Use the lantern or run!', 1600); } else { s.st = 'leave'; s.t = 1.6; A().sfx('whisper'); } } return; }
      if (s.st === 'stun') { s.t -= dt; s.x -= s.face * 150 * dt; s.x = Math.max(0, Math.min(L.w, s.x)); s.a = Math.max(.25, s.a - dt * .5); if (s.t <= 0) { s.st = 'leave'; s.t = .8; } return; }
      if (s.st === 'leave') { s.t -= dt; s.a = Math.max(0, s.a - dt * .9); this.fear = Math.max(0, this.fear - dt * .5); if (s.t <= 0) { if (this.tut) { this.tut = false; TLR.Save.data.tut = true; this.tip = 0; } s.st = 'idle'; s.a = 0; s.t = L.boss ? R(5, 9) : Math.max(12, (R(30, 52) - this.chap() * 2.2) * this.D().iv); } }
    },
    curse(msg) { const s = this.s; if (!s || s.st !== 'idle') return; this.spawn(msg); },
    spawn(msg) {
      const G = TLR.Game, p = G.p, L = G.L, s = this.s, side = p.x > L.w / 2 ? -1 : 1;
      s.x = Math.max(30, Math.min(L.w - 30, p.x + side * R(460, 560))); if (Math.abs(s.x - p.x) < 380) s.x = Math.max(30, Math.min(L.w - 30, p.x - side * 480));
      s.type = this.pickType(); if (this.tut) s.type = 'wailer'; s.tx = null; s.wander = 0; s.st = 'warn'; s.t = 2.4; s.a = .01; s.hunt = 0; this.vib([220, 90, 220]); if (this.tut) this.tip = 9; A().sfx('whisper'); TLR.UI.toast(msg || TLR.I18N.t('Something is coming... hide, light it up, or run!'), 3200);
    },
    /* the lantern: a blinding flash in front of the player */
    flash() {
      const G = TLR.Game, p = G.p, s = this.s; if (G.mode !== 'play' || G.blocked() || this.cd > 0) return; if (p.hidden && !(s && s.st === 'found')) return;
      this.flashT = .38; A().sfx('zap'); let hit = false;
      if (s && this.enabled && (s.st === 'hunt' || s.st === 'warn' || s.st === 'sniff' || s.st === 'found')) { const dx = s.x - p.x; if (s.st === 'found' || dx * p.face > 0 && Math.abs(dx) < 230) { hit = true; s.st = 'stun'; s.t = TLR.Game.L.boss ? 3.6 : 3.2; this.vib(80); this.tip = 0; s.face = dx >= 0 ? 1 : -1; this.fear = Math.max(0, this.fear - .4); A().sfx('scare'); } }
      this.cd = hit ? 5.5 : 1.4; this.noise(p.x, 500); TLR.UI.setLight && TLR.UI.setLight(this.cd);
    },
    kill() {
      const G = TLR.Game, s = this.s; if (G.mode !== 'play') return; if (this.tut) { this.tut = false; TLR.Save.data.tut = true; this.tip = 0; s.st = 'leave'; s.t = 1; A().sfx('scare'); this.shake = .4; this.vib(300); TLR.UI.toast('That was close! Next time it will not stop.', 3800); return; } G.lvDeaths = (G.lvDeaths || 0) + 1; TLR.Save.data.deaths = (TLR.Save.data.deaths || 0) + 1; this.vib(500); G.mode = 'over'; this.over = 0; this.shake = .7; A().sfx('scare'); TLR.Input.clear();
      s.face = G.p.x >= s.x ? 1 : -1; s.x = G.p.x - s.face * 20;
    },
    updateOver(dt) { const G = TLR.Game; this.over += dt; if (this.over > 1.5 && !this.shown) { this.shown = true; TLR.UI.gameOver(); } },
    /* in world coordinates (camera transform already applied) */
    draw(c, t) {
      const G = TLR.Game, s = this.s, p = G.p; if (!s || s.st === 'idle' || s.a <= .02) return;
      const y = G.floorY, flick = s.st === 'warn' ? (Math.sin(t * 40) > 0 ? 1 : .3) : 1, al = Math.min(1, s.a) * flick * (s.st === 'stun' ? .55 + Math.sin(t * 30) * .3 : 1);
      this.body(c, s.x, y, t, s.face, al, (G.L.boss ? 1.4 : 1), (s.st === 'hunt' || s.st === 'found') && Math.abs(p.x - s.x) < 160, s.frozen, s.type);
    },
    body(c, x, y, t, face, al, sc, wide, frozen, type) {
      c.save(); c.translate(x + Math.sin(t * 1.7) * 2, y - 8 + Math.sin(t * 2.3) * 4); c.scale(face * sc, sc); c.globalAlpha = Math.max(0, Math.min(1, al));
      const glow = U.rg ? U.rg(c, 0, -52, 4, 70, [[0, 'rgba(190,210,255,.28)'], [1, 'rgba(190,210,255,0)']]) : null; if (glow) { c.fillStyle = glow; c.fillRect(-70, -122, 140, 140); }
      /* gown */
      const gg = c.createLinearGradient(0, -80, 0, 8); gg.addColorStop(0, '#e8ecf8'); gg.addColorStop(1, 'rgba(200,210,235,.05)');
      c.fillStyle = gg; c.beginPath(); c.moveTo(-9, -80); c.quadraticCurveTo(-26, -40, -22, 8 + Math.sin(t * 5) * 3); for (let i = 0; i < 6; i++) c.lineTo(-22 + i * 8.8 + 4, 8 + (i % 2 ? 9 : -2) + Math.sin(t * 4 + i) * 3); c.quadraticCurveTo(26, -40, 9, -80); c.closePath(); c.fill();
      /* arms hanging */
      c.strokeStyle = 'rgba(225,230,245,.85)'; c.lineWidth = 3.4; c.lineCap = 'round'; c.beginPath(); c.moveTo(-9, -70); c.quadraticCurveTo(-22, -45, -18 + Math.sin(t * 2) * 3, -22); c.moveTo(9, -70); c.quadraticCurveTo(24, -52, 30 + Math.sin(t * 2 + 1) * 3, -34); c.stroke();
      /* hair */
      c.fillStyle = '#07060b'; c.beginPath(); c.ellipse(0, -90, 16, 20, 0, 0, TAU); c.fill();
      for (let i = -3; i <= 3; i++) { c.beginPath(); c.moveTo(i * 4.5 - 3, -84); c.quadraticCurveTo(i * 8 + Math.sin(t * 2 + i) * 4, -55, i * 6 + Math.sin(t * 3 + i) * 5, -26 - Math.abs(i) * 4); c.lineTo(i * 4.5 + 3, -84); c.fill(); }
      /* face */
      c.fillStyle = '#d9dcec'; c.beginPath(); c.ellipse(0, -88, 10, 13, 0, 0, TAU); c.fill();
      c.fillStyle = '#05040a'; c.beginPath(); c.ellipse(-4, -91, 2.6, 4, 0, 0, TAU); c.ellipse(4, -91, 2.6, 4, 0, 0, TAU); c.fill();
      c.fillStyle = frozen ? 'rgba(255,255,255,.9)' : (type === 'sensor' ? 'rgba(90,255,160,.95)' : type === 'seeker' ? 'rgba(255,170,60,.95)' : type === 'watcher' ? 'rgba(180,120,255,.95)' : 'rgba(255,70,70,.95)'); c.beginPath(); c.arc(-4, -91, frozen ? .6 : 1.3, 0, TAU); c.arc(4, -91, frozen ? .6 : 1.3, 0, TAU); c.fill();
      c.fillStyle = '#05040a'; c.beginPath(); c.ellipse(0, -81, wide ? 4 : 2.2, wide ? 7 : 3.2, 0, 0, TAU); c.fill();
      c.restore();
    },
    /* world overlay: lantern beam */
    drawBeam(c) {
      const G = TLR.Game, p = G.p; if (this.flashT <= 0) return; const k = this.flashT / .38, d = p.face;
      c.save(); c.globalCompositeOperation = 'lighter'; const gr = c.createLinearGradient(p.x, 0, p.x + d * 260, 0); gr.addColorStop(0, 'rgba(255,248,210,' + .75 * k + ')'); gr.addColorStop(1, 'rgba(255,248,210,0)');
      c.fillStyle = gr; c.beginPath(); c.moveTo(p.x + d * 8, p.y - 38); c.lineTo(p.x + d * 260, p.y - 120); c.lineTo(p.x + d * 260, p.y + 20); c.closePath(); c.fill(); c.restore();
    },
    /* screen overlay: fear vignette, off-screen warning, white flash, jump scare */
    drawScreen(c, W, H) {
      const G = TLR.Game, s = this.s, t = G.t; c.setTransform(1, 0, 0, 1, 0, 0);
      if (this.fear > .02) { const gr = c.createRadialGradient(W / 2, H / 2, H * .25, W / 2, H / 2, H * .85); gr.addColorStop(0, 'rgba(120,0,0,0)'); gr.addColorStop(1, 'rgba(150,0,10,' + (.5 * this.fear * (.8 + .2 * Math.sin(t * 9))) + ')'); c.fillStyle = gr; c.fillRect(0, 0, W, H); }
      if (this.flashT > 0) { c.fillStyle = 'rgba(255,250,220,' + .35 * (this.flashT / .38) + ')'; c.fillRect(0, 0, W, H); }
      if (s && this.enabled && (s.st === 'warn' || s.st === 'hunt') && G.mode === 'play') {
        const cam = G.cam, sx = (s.x - cam.x) * (W / G.view.w);
        if (sx < 10 || sx > W - 10) { const left = sx < 10, ex = left ? 34 : W - 34, ey = H * .45, pu = 1 + Math.sin(t * 8) * .12; c.save(); c.translate(ex, ey); c.scale(pu, pu); c.fillStyle = 'rgba(255,60,60,.95)'; c.beginPath(); c.moveTo(left ? -22 : 22, 0); c.lineTo(left ? -4 : 4, -14); c.lineTo(left ? -4 : 4, 14); c.closePath(); c.fill(); c.fillStyle = 'rgba(14,6,10,.9)'; c.beginPath(); c.arc(0, 0, 18, 0, TAU); c.fill(); c.strokeStyle = '#ff4a4a'; c.lineWidth = 2.5; c.stroke(); c.fillStyle = '#ffd7d7'; c.beginPath(); c.ellipse(0, -2, 7, 9, 0, 0, TAU); c.fill(); c.fillStyle = '#05040a'; c.fillRect(-4, -5, 3, 4); c.fillRect(1, -5, 3, 4); c.restore(); }
      }
      if (this.tip > 0 && G.mode === 'play') {
        const k = Math.min(1, this.tip), cx = W / 2, cy = H * .42, R2 = Math.min(W, H) * .075, gap = R2 * 2.7; c.save(); c.globalAlpha = k; c.fillStyle = 'rgba(8,6,16,.7)'; c.fillRect(cx - gap * 1.6, cy - R2 * 1.5, gap * 3.2, R2 * 3); c.strokeStyle = '#ffe08a'; c.lineWidth = 2; c.strokeRect(cx - gap * 1.6, cy - R2 * 1.5, gap * 3.2, R2 * 3);
        const pul = 1 + Math.sin(t * 6) * .07;
        c.save(); c.translate(cx - gap, cy); c.scale(pul, pul); TLR.Guide.badge(c, 'hide', 0, 0, R2, 1); c.restore();
        c.save(); c.translate(cx, cy); c.scale(pul, pul); TLR.Guide.badge(c, 'pick', 0, 0, R2, 1); c.fillStyle = '#ffe9a8'; c.strokeStyle = '#ffe9a8'; c.lineWidth = R2 * .12; c.beginPath(); c.arc(0, -R2 * .05, R2 * .22, 0, TAU); c.fill(); for (let i = -2; i <= 2; i++) { c.beginPath(); c.moveTo(R2 * .3, i * R2 * .14); c.lineTo(R2 * .68, i * R2 * .26); c.stroke(); } c.restore();
        c.save(); c.translate(cx + gap, cy); c.scale(pul, pul); TLR.Guide.badge(c, 'door', 0, 0, R2, 1); c.fillStyle = '#ffe9a8'; for (let i = 0; i < 2; i++) { c.beginPath(); c.moveTo(-R2 * .1 + i * R2 * .28, -R2 * .3); c.lineTo(R2 * .2 + i * R2 * .28, 0); c.lineTo(-R2 * .1 + i * R2 * .28, R2 * .3); c.fill(); } c.restore();
        c.restore();
      }
      if (G.mode === 'over') {
        const k = Math.min(1, this.over / .35); c.fillStyle = 'rgba(0,0,0,' + (.55 + .4 * Math.min(1, this.over)) + ')'; c.fillRect(0, 0, W, H);
        const z = 1.4 + this.over * .7 + (Math.random() - .5) * .08; c.save(); c.translate(W / 2 + (Math.random() - .5) * 14, H * .92); this.body(c, 0, 0, t, 1, k, H / 150 * z * .55, true); c.restore();
        if (this.over < .25) { c.fillStyle = 'rgba(255,255,255,' + (.7 - this.over * 2.8) + ')'; c.fillRect(0, 0, W, H); }
      }
    }
  };
})(window);
