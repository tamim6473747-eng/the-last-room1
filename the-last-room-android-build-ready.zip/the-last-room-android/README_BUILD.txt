How to build the APK (free, ~15 minutes)
1. Install Android Studio (https://developer.android.com/studio).
2. File > Open > choose this folder (TheLastRoom). Let it sync (it downloads Gradle and the SDK).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. When it finishes click "locate": app-debug.apk is in app/build/outputs/apk/debug/.
5. Copy it to the phone, open it, allow "install unknown apps".
For the Play Store you need a signed release AAB: Build > Generate Signed Bundle / APK.
